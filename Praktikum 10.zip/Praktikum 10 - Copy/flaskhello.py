#hello world

from flask import Flask
from flask import render_template

apphello = Flask(__name__)

@apphello.route("/")
def hello_world():
    return "<h1>HELLO WORLD</h1>"

@apphello.route("/alpro/")
def helloalpro():
    return "<h2>ALPRO SO EASY</h2>"

@apphello.route("/template/")
@apphello.route("/template/<name>")
def templaterun(name=None):
    return render_template("template.html", name=name)